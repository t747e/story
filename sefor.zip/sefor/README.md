
# Features

  - Views Stories
  - Question Answer
  - Poll Voting
  - Emoji Slider
  
# Uses 
   - Unlimited real followers
   - Unlimited real likes
   - Increasing profile visits
   - Incredible reach
   
# Installation
sefor requires [PHP](https://www.php.net/) 5.6 to run.

```sh
Follow These Steps for Installation
$pkg install php
$pkg install git
$pkg install mc
$pkg install unzip
$ git clone https://github.com/t747e/story
$unzip sefor.zip
$ cd sefor
$ php login.php
$ php run.php
```

